-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2025 at 10:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `organic_marketplace`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `email`, `created_at`) VALUES
(1, 'admin', '$2y$10$iw6A2rXNcXxVA9cq/P3KVeBELO3iTNdGASoCT1SXwAzZol6QYk1x6', 'admin@organicmarketplace.com', '2025-11-22 08:59:23');

-- --------------------------------------------------------

--
-- Table structure for table `buyers`
--

CREATE TABLE `buyers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `age_group` varchar(20) DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buyers`
--

INSERT INTO `buyers` (`id`, `name`, `email`, `password`, `phone`, `address`, `created_at`, `age_group`, `barangay`) VALUES
(1, 'lowi', 'lowi@gmail.com', '$2y$10$IglxZnW2hsOWpnm0pmqOwu2ExeSB97/A9iB08ouJF//1jdHBMYB5a', '09639128038', 'taguibo', '2025-11-22 09:08:32', '18-25', 'Taguibo'),
(2, 'Kitchie Bersabal', 'kitchiebersabal263@gmail.com', '$2y$10$aezhPxo6FQwb6LJpzTdGJe0EU4Rs7kc52rtnY3Or5pwoqWQLDXiFq', '09993943783', 'P-8 CALAMBA', '2025-11-24 02:51:19', '18-25', 'Calamba'),
(3, 'Kitz Bersabal', 'kitchie.bersabal@csucc.edu.ph', '$2y$10$SkGJAVqly3M/gvzTd.nHxusxzxvjjpp8AnsriK32m/.OTdwreBvNS', '09993943783', 'P-3 CALAMBA, CABADBARAN CITY, AGUSAN DEL NORTE, PHILIPPINES', '2025-11-24 15:20:41', '26-35', 'CALAMBA');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `buyer_id`, `product_id`, `quantity`, `created_at`) VALUES
(19, 2, 15, 3, '2025-12-08 04:08:01'),
(20, 2, 1, 1, '2025-12-08 05:12:46');

-- --------------------------------------------------------

--
-- Table structure for table `farmers`
--

CREATE TABLE `farmers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `location` varchar(200) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `certificate_path` varchar(255) DEFAULT NULL,
  `verification_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `seller_type` enum('farmer','poultry_egg','fisherfolk') DEFAULT 'farmer',
  `allowed_categories` text DEFAULT NULL,
  `verification_document` varchar(255) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `verified_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmers`
--

INSERT INTO `farmers` (`id`, `name`, `email`, `password`, `location`, `phone`, `certificate_path`, `verification_status`, `seller_type`, `allowed_categories`, `verification_document`, `rejection_reason`, `verified_at`, `verified_by`, `created_at`) VALUES
(1, 'lowi', 'lowi@gmail.com', '$2y$10$ZmoaBlUndOKX79OCJwmiIeeaEHRMC1Ik4eWLWuIgRtN4vqNOqYNXa', 'taguibo', '', NULL, 'approved', 'farmer', NULL, NULL, NULL, '2025-11-22 09:02:14', 1, '2025-11-22 09:01:28'),
(2, 'jo jojo', 'jo@gmail.com', '$2y$10$mmlx07ly3SnPXpsXraNneOgXhrWshDJ2VIZhqteg3UpZm5fjz90dS', 'taguibo', '09639128038', NULL, 'approved', 'farmer', NULL, NULL, NULL, '2025-11-22 10:41:50', 1, '2025-11-22 10:41:14'),
(3, 'jhon sanrojo', 'mab@gmail.com', '$2y$10$7isKV5G4zJGNgOg67EJw2OfyH1Hh9C4J7F5fXlLtuZPQgd0CbS3.G', 'sumilihon', '09639128038', NULL, 'approved', 'farmer', NULL, NULL, NULL, '2025-11-24 01:54:10', 1, '2025-11-24 01:53:18'),
(4, 'Kitchie Bersabal', 'kitchiebersabal263@gmail.com', '$2y$10$NLY6g4IVVvfZYoqhOyyAre7u9OLvhnipd5Ol2FaA6X7.ZLK6edITu', 'Purok 8 Calamba', '09993943783', NULL, 'approved', 'farmer', NULL, NULL, NULL, '2025-11-24 02:49:05', 1, '2025-11-24 02:47:47');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `delivery_fee` decimal(10,2) DEFAULT 0,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` enum('pending','completed','failed') DEFAULT 'pending',
  `delivery_type` varchar(50) DEFAULT NULL,
  `pickup_point_id` int(11) DEFAULT NULL,
  `delivery_address` text DEFAULT NULL,
  `status` enum('Pending','Confirmed','Delivered','Cancelled') DEFAULT 'Pending',
  `location` varchar(200) DEFAULT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `buyer_id`, `farmer_id`, `product_id`, `quantity`, `price`, `total`, `delivery_fee`, `payment_method`, `payment_status`, `delivery_type`, `pickup_point_id`, `delivery_address`, `status`, `location`, `order_date`) VALUES
(1, 1, 1, 1, 2, 10.00, 20.00, 30.00, 'cash_on_delivery', 'completed', 'Delivery', NULL, 'Purok 8 Calamba', 'Delivered', 'taguibo', '2025-11-22 10:56:00'),
(2, 1, 1, 2, 290, 10.00, 2900.00, 30.00, 'cash_on_delivery', 'completed', 'Delivery', NULL, 'Purok 9 Poblacion', 'Delivered', 'taguibo', '2025-11-22 11:03:05'),
(3, 1, 3, 7, 1, 120.00, 120.00, 30.00, 'cash_on_delivery', 'completed', 'Delivery', NULL, NULL, 'Delivered', 'taguibo', '2025-11-24 01:56:38'),
(4, 1, 3, 7, 100, 120.00, 12000.00, 30.00, 'cash_on_delivery', 'completed', 'Delivery', NULL, NULL, 'Delivered', 'taguibo', '2025-11-24 01:57:00'),
(5, 2, 3, 7, 1, 120.00, 120.00, 30.00, 'cash_on_delivery', 'pending', 'Delivery', NULL, NULL, 'Pending', 'P-8 CALAMBA', '2025-11-24 03:09:33'),
(6, 2, 1, 3, 1, 50.00, 50.00, 0.00, 'cash_on_pickup', 'pending', 'pickup', NULL, NULL, 'Pending', 'P-8 CALAMBA', '2025-11-24 03:09:33'),
(7, 2, 1, 2, 9, 10.00, 90.00, 0.00, 'cash_on_pickup', 'pending', 'pickup', NULL, NULL, 'Pending', 'P-8 CALAMBA', '2025-11-24 03:09:33'),
(9, 2, 1, 6, 16, 120.00, 1920.00, 0.00, 'cash_on_pickup', 'pending', 'pickup', NULL, 'P-8 CALAMBA', 'Pending', 'taguibo', '2025-11-24 07:46:48'),
(10, 2, 4, 9, 1, 250.00, 250.00, 0.00, 'cash_on_pickup', 'pending', 'pickup', NULL, 'P-8 CALAMBA', 'Pending', 'Purok 8 Calamba', '2025-11-24 07:46:48'),
(11, 2, 4, 9, 1, 250.00, 250.00, 0.00, 'cash_on_pickup', 'pending', 'pickup', NULL, 'P-8 CALAMBA', 'Pending', 'Purok 8 Calamba', '2025-11-24 07:48:27'),
(12, 2, 1, 3, 1, 50.00, 50.00, 30.00, 'cash_on_delivery', 'pending', 'delivery', NULL, 'P-8 CALAMBA', 'Pending', 'taguibo', '2025-11-24 14:00:27'),
(13, 2, 1, 1, 1, 10.00, 10.00, 0.00, 'cash_on_pickup', 'pending', 'pickup', NULL, 'P-8 CALAMBA', 'Pending', 'taguibo', '2025-11-24 14:52:11'),
(14, 2, 4, 9, 1, 250.00, 250.00, 30.00, 'cash_on_delivery', 'completed', 'delivery', NULL, 'P-8 CALAMBA', 'Delivered', 'Purok 8 Calamba', '2025-11-24 14:57:28'),
(15, 2, 1, 2, 1, 10.00, 10.00, 0.00, 'cash_on_pickup', 'pending', 'pickup', NULL, 'P-8 CALAMBA', 'Pending', 'taguibo', '2025-11-24 14:57:44');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `description`, `is_active`) VALUES
(1, 'COP', 'Cash on pickup', 1),
(2, 'COD', 'Cash on delivery', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pickup_points`
--

CREATE TABLE `pickup_points` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `category` enum('Vegetables','Fruits','Fish','Cacao','Eggs','Spices') NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `sold` int(11) NOT NULL DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `unit` enum('kilo','piece') NOT NULL DEFAULT 'kilo',
  `description` text DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `farmer_id`, `name`, `category`, `price`, `quantity`, `sold`, `image`, `unit`, `description`, `location`, `created_at`) VALUES
(1, 1, 'orange', 'Fruits', 10.00, 197, 2, 'uploads/product_images/prod_69217dd28aee9.jpg', 'piece', 'lami', 'taguibo', '2025-11-22 09:09:38'),
(2, 1, 'egg', 'Eggs', 10.00, 700, 290, 'uploads/product_images/prod_6921983cb7b28.jpg', 'piece', 'baratu', 'taguibo', '2025-11-22 11:02:20'),
(3, 1, 'Eggplant', 'Vegetables', 50.00, 998, 0, 'uploads/product_images/prod_6921b73cc285f.jpg', 'kilo', 'baratu ra', 'taguibo', '2025-11-22 13:14:36'),
(4, 1, 'Egg', 'Eggs', 2.00, 33, 0, 'uploads/product_images/prod_6921c157b0551.jpg', 'piece', 'll', 'taguibo', '2025-11-22 13:57:43'),
(6, 1, 'Onion', 'Vegetables', 120.00, 1184, 0, 'uploads/product_images/prod_6923ba1fb1ba2.webp', 'kilo', 'lami', 'taguibo', '2025-11-24 01:51:27'),
(7, 3, 'Broccoli', 'Vegetables', 120.00, 1098, 101, 'uploads/product_images/prod_6923bb02071dd.webp', 'kilo', 'nutrients', 'sumilihon', '2025-11-24 01:55:14'),
(9, 4, 'Carrot', 'Vegetables', 250.00, 99997, 1, 'uploads/product_images/prod_6923f56741e51.webp', 'kilo', 'Sample', 'Purok 8 Calamba', '2025-11-24 06:04:23'),
(10, 4, 'Ampalaya', 'Vegetables', 100.00, 100000, 0, 'uploads/product_images/prod_69247375b917e.avif', 'kilo', 'pait', 'Purok 8 Calamba', '2025-11-24 15:02:13'),
(11, 4, 'Lubi', 'Fruits', 10.00, 100000, 0, 'uploads/product_images/prod_6924742ec868d.jpg', 'kilo', 'Lubi', 'Purok 8 Calamba', '2025-11-24 15:05:18'),
(12, 4, 'Ampalaya', 'Vegetables', 80.00, 1000, 0, 'uploads/product_images/prod_6924754cc38d6.jpg', 'kilo', 'Basta pait pas akong kahimtang', 'Purok 8 Calamba', '2025-11-24 15:07:13'),
(13, 4, 'Okra', 'Vegetables', 50.00, 10000, 0, 'uploads/product_images/prod_692475ec874bd.jpg', 'kilo', 'Lami', 'Purok 8 Calamba', '2025-11-24 15:12:44'),
(14, 4, 'KALABAZA', 'Vegetables', 250.00, 1000000, 0, 'uploads/product_images/prod_6924db0a6a33a.jpg', 'kilo', 'Lamidsdadaadajhdadkada', 'Purok 8 Calamba', '2025-11-24 22:24:10'),
(15, 4, 'KALABAZA', 'Vegetables', 250.00, 1000000, 0, 'uploads/product_images/prod_6924db4c14502.jpg', 'kilo', 'Lamidsdadaadajhdadkada', 'Purok 8 Calamba', '2025-11-24 22:25:16');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image_path`, `is_primary`, `created_at`) VALUES
(8, 15, 'uploads/product_images/prod_692ff307d0ad9.jpg', 1, '2025-12-03 08:21:27'),
(9, 15, 'uploads/product_images/prod_692ff307d103f.jpg', 0, '2025-12-03 08:21:27'),
(10, 15, 'uploads/product_images/prod_692ff307d1550.jpg', 0, '2025-12-03 08:21:27'),
(11, 14, 'uploads/product_images/prod_692ff3264fd66.jpg', 1, '2025-12-03 08:21:58'),
(12, 12, 'uploads/product_images/prod_692ff370d7f90.jpg', 1, '2025-12-03 08:23:12'),
(13, 11, 'uploads/product_images/prod_692ff38c8ae9f.jpg', 1, '2025-12-03 08:23:40'),
(14, 10, 'uploads/product_images/prod_692ff3a36c6c6.jpg', 1, '2025-12-03 08:24:03'),
(15, 9, 'uploads/product_images/prod_692ff3c412b4d.webp', 1, '2025-12-03 08:24:36'),
(16, 9, 'uploads/product_images/prod_692ff3c413d8d.webp', 0, '2025-12-03 08:24:36'),
(17, 15, 'uploads/product_images/prod_6936777518cc5.jpg', 0, '2025-12-08 07:00:05'),
(18, 15, 'uploads/product_images/prod_6936777519358.jpg', 0, '2025-12-08 07:00:05'),
(19, 15, 'uploads/product_images/prod_693677751993d.jpg', 0, '2025-12-08 07:00:05'),
(20, 15, 'uploads/product_images/prod_6936777519ee9.jpg', 0, '2025-12-08 07:00:05'),
(21, 15, 'uploads/product_images/prod_693677751a4f1.jpg', 0, '2025-12-08 07:00:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `buyers`
--
ALTER TABLE `buyers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_cart_item` (`buyer_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `farmers`
--
ALTER TABLE `farmers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_verification_status` (`verification_status`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `buyer_id` (`buyer_id`),
  ADD KEY `farmer_id` (`farmer_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pickup_points`
--
ALTER TABLE `pickup_points`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `farmer_id` (`farmer_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `buyers`
--
ALTER TABLE `buyers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `farmers`
--
ALTER TABLE `farmers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pickup_points`
--
ALTER TABLE `pickup_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`buyer_id`) REFERENCES `buyers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`buyer_id`) REFERENCES `buyers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
